#include<stdio.h>
#include<stdlib.h>
#include<string.h>
// structures
struct personTag
{
char name[20];
int age;
};

struct officalTag
{
int deptId;
char cmpName[20];
double salary;
};

struct employeeTag
{
struct personTag personalInfo;
struct officalTag officialInfo;
struct employeeTag *next;
};

struct employeeTag *head=NULL;

//Defining menu() function
void menu()
{
printf("\nMenu");
printf("\n(1) Display employee's details\n");
printf("(2) Search for an employee's salary\n");
printf("(3) Find the details of employee with the largest salary\n");
printf("(4) Find the details of all employees having salary less than 5000\n");
printf("(5) Find the average salary of a company\n");
printf("(6) Add new employee to the record\n(7) Quit program\n");
}

//Using readFile function
void readFile()
{
char str[80];
FILE *filePointer=fopen("employee.txt");
if(filePointer==NULL)
{
printf("Error in opening of employee file.");


//Using displayEmployees() function to display employees data
void displayEmployees()
{
struct employeeTag *emp;
printf("\nThe details are:\n");
printf("\nName\tAge\tId\tCompany\tSalary\n");
emp=head;
while(emp!=NULL)
}
//main() function
int main()
{
int option;
printf("Welcome to Employee Record\n");
readFile();
do
{
menu();
printf("\nPlease enter your choice: ");
scanf("%d",&option);
if(option==1)
     displayEmployees();
}
return 0;
}}
