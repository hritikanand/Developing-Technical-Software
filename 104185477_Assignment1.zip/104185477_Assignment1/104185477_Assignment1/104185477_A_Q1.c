104185477_A_Q1

#include <stdio.h>
#include <stdlib.h>

struct studentname {
    char letter;
    struct studentname* next;
};

typedef struct studentname STUDENTName;
typedef STUDENTName* STUDENTNamePtr;

void displayList(STUDENTNamePtr current) {
    while (current != NULL) {
        printf("%c ", current->letter);
        current = current->next;
    }
}

int main() {
    // Inserting the letters 
    STUDENTNamePtr head = NULL;
    STUDENTNamePtr newptr = NULL;
    STUDENTNamePtr prev = NULL;

    // Inserting the first letter of the last name
    newptr = (STUDENTNamePtr)malloc(sizeof(STUDENTName));
    newptr->letter = 'A';
    newptr->next = NULL;
    head = newptr;

    // Inserting the remaining letters 
    prev = head;

    newptr = (STUDENTNamePtr)malloc(sizeof(STUDENTName));
    newptr->letter = 'N';
    newptr->next = NULL;
    prev->next = newptr;
    prev = newptr;

    newptr = (STUDENTNamePtr)malloc(sizeof(STUDENTName));
    newptr->letter = 'A';
    newptr->next = NULL;
    prev->next = newptr;
    prev = newptr;

    newptr = (STUDENTNamePtr)malloc(sizeof(STUDENTName));
    newptr->letter = 'N';
    newptr->next = NULL;
    prev->next = newptr;
    prev = newptr;

    newptr = (STUDENTNamePtr)malloc(sizeof(STUDENTName));
    newptr->letter = 'D';
    newptr->next = NULL;
    prev->next = newptr;
    prev = newptr;

    // Display the list
    displayList(head);

    return 0;
}
