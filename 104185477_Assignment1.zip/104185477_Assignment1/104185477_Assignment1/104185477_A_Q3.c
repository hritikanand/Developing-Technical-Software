#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TRAIN_COUNT 10

//Declaring structure
struct Train {
    int id;
    int time;
};

// function for filling id for each train with random integer between 100 and 200
void fillTrainDetails(struct Train trains[], int size) 
{
    for (int i = 0; i < size; i++) 
	{
        trains[i].id = rand() % 101 + 100;
    }
}

//function to fill in time for each train with random integer between 1 and 24
void fillTrainSchedule(struct Train trains[], int size) 
{
    for (int i = 0; i < size; i++) 
	{
        trains[i].time = rand() % 24 + 1;
    }
}

//function to print out details for each train
void printTrainDetails(struct Train trains[], int size) 
{
    for (int i = 0; i < size; i++) 
	{
        printf("Train %d is to depart at %d:00\n", trains[i].id, trains[i].time);
    }
}

//void sortTrainsByTime(struct Train) 
//{
//   for (int i = 0; i < size; i++)
//}           

    
//Main function
int main() {
    srand(time(NULL));
    struct Train trains[TRAIN_COUNT];

    fillTrainDetails(trains, TRAIN_COUNT);
    fillTrainSchedule(trains, TRAIN_COUNT);
    printTrainDetails(trains, TRAIN_COUNT);

    return 0;
}
